# AYASCELL PC Optimizer v1.0.0 Installer Script
# Copyright (c) 2025 AYASCELL. All rights reserved.

param(
    [switch]$Uninstall,
    [string]$InstallPath = "$env:ProgramFiles\AYASCELL PC Optimizer",
    [switch]$CreateDesktopShortcut = $true,
    [switch]$CreateStartMenuShortcut = $true
)

# Require Administrator privileges
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Bu installer yönetici yetkileri gerektirir. PowerShell'i yönetici olarak çalıştırın." -ForegroundColor Red
    Write-Host "Sağ tıklayın > 'Yönetici olarak çalıştır' seçeneğini kullanın." -ForegroundColor Yellow
    pause
    exit 1
}

$AppName = "AYASCELL PC Optimizer"
$AppVersion = "1.0.0"
$ExecutableName = "AYASCELL.PcOptimizer.exe"
$AppDescription = "Windows PC optimization and cleaning tool"

function Write-ColorText($text, $color = "White") {
    Write-Host $text -ForegroundColor $color
}

function Show-Header {
    Clear-Host
    Write-ColorText "================================================================" "Cyan"
    Write-ColorText "           AYASCELL PC Optimizer v$AppVersion Installer" "Yellow"
    Write-ColorText "================================================================" "Cyan"
    Write-ColorText ""
}

function Test-Installation {
    return (Test-Path "$InstallPath\$ExecutableName")
}

function Install-Application {
    Show-Header
    Write-ColorText "🚀 KURULUM BAŞLATILIYOR..." "Green"
    Write-ColorText ""
    
    try {
        # Create installation directory
        Write-ColorText "📁 Kurulum dizini oluşturuluyor: $InstallPath" "Gray"
        if (-not (Test-Path $InstallPath)) {
            New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
        }
        
        # Check if executable exists in current directory
        $SourceExe = Join-Path $PSScriptRoot $ExecutableName
        if (-not (Test-Path $SourceExe)) {
            Write-ColorText "❌ HATA: $ExecutableName bu dizinde bulunamadı!" "Red"
            Write-ColorText "Installer'ı executable ile aynı klasöre koyun." "Yellow"
            return $false
        }
        
        # Copy executable
        Write-ColorText "📦 Uygulama dosyası kopyalanıyor..." "Gray"
        Copy-Item $SourceExe -Destination "$InstallPath\$ExecutableName" -Force
        
        # Copy README if exists
        $SourceReadme = Join-Path $PSScriptRoot "README.md"
        if (Test-Path $SourceReadme) {
            Copy-Item $SourceReadme -Destination "$InstallPath\README.md" -Force
        }
        
        # Create desktop shortcut
        if ($CreateDesktopShortcut) {
            Write-ColorText "🖥️ Masaüstü kısayolu oluşturuluyor..." "Gray"
            $DesktopPath = [Environment]::GetFolderPath("Desktop")
            $ShortcutPath = "$DesktopPath\$AppName.lnk"
            
            $WshShell = New-Object -comObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
            $Shortcut.TargetPath = "$InstallPath\$ExecutableName"
            $Shortcut.WorkingDirectory = $InstallPath
            $Shortcut.Description = $AppDescription
            $Shortcut.Save()
        }
        
        # Create Start Menu shortcut
        if ($CreateStartMenuShortcut) {
            Write-ColorText "📋 Başlat menüsü kısayolu oluşturuluyor..." "Gray"
            $StartMenuPath = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
            $ShortcutPath = "$StartMenuPath\$AppName.lnk"
            
            $WshShell = New-Object -comObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
            $Shortcut.TargetPath = "$InstallPath\$ExecutableName"
            $Shortcut.WorkingDirectory = $InstallPath
            $Shortcut.Description = $AppDescription
            $Shortcut.Save()
        }
        
        # Add to Windows Programs and Features (Registry)
        Write-ColorText "📝 Windows kayıt defterine ekleniyor..." "Gray"
        $RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$AppName"
        New-Item -Path $RegPath -Force | Out-Null
        Set-ItemProperty -Path $RegPath -Name "DisplayName" -Value $AppName
        Set-ItemProperty -Path $RegPath -Name "DisplayVersion" -Value $AppVersion
        Set-ItemProperty -Path $RegPath -Name "Publisher" -Value "AYASCELL"
        Set-ItemProperty -Path $RegPath -Name "InstallLocation" -Value $InstallPath
        Set-ItemProperty -Path $RegPath -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Uninstall"
        Set-ItemProperty -Path $RegPath -Name "DisplayIcon" -Value "$InstallPath\$ExecutableName"
        Set-ItemProperty -Path $RegPath -Name "EstimatedSize" -Value 200000  # KB
        
        Write-ColorText ""
        Write-ColorText "✅ KURULUM BAŞARIYLA TAMAMLANDI!" "Green"
        Write-ColorText ""
        Write-ColorText "📍 Kurulum Dizini: $InstallPath" "Cyan"
        Write-ColorText "🖥️ Masaüstü Kısayolu: " -NoNewline; Write-ColorText $(if($CreateDesktopShortcut){"Oluşturuldu"}else{"Oluşturulmadı"}) "Yellow"
        Write-ColorText "📋 Başlat Menüsü: " -NoNewline; Write-ColorText $(if($CreateStartMenuShortcut){"Eklendi"}else{"Eklenmedi"}) "Yellow"
        Write-ColorText ""
        Write-ColorText "🚀 Uygulamayı başlatmak için masaüstü kısayolunu kullanın" "Green"
        Write-ColorText "   veya Başlat menüsünden '$AppName' arayın." "Green"
        Write-ColorText ""
        Write-ColorText "⚠️  İlk çalıştırma için 'Yönetici olarak çalıştır' önerilir." "Yellow"
        
        return $true
        
    } catch {
        Write-ColorText "❌ KURULUM HATASI: $($_.Exception.Message)" "Red"
        return $false
    }
}

function Uninstall-Application {
    Show-Header
    Write-ColorText "🗑️ KALDIRMA İŞLEMİ BAŞLATILIYOR..." "Yellow"
    Write-ColorText ""
    
    try {
        # Remove installation directory
        if (Test-Path $InstallPath) {
            Write-ColorText "📁 Kurulum dizini siliniyor..." "Gray"
            Remove-Item -Path $InstallPath -Recurse -Force
        }
        
        # Remove desktop shortcut
        $DesktopShortcut = "$([Environment]::GetFolderPath("Desktop"))\$AppName.lnk"
        if (Test-Path $DesktopShortcut) {
            Write-ColorText "🖥️ Masaüstü kısayolu siliniyor..." "Gray"
            Remove-Item $DesktopShortcut -Force
        }
        
        # Remove Start Menu shortcut
        $StartMenuShortcut = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\$AppName.lnk"
        if (Test-Path $StartMenuShortcut) {
            Write-ColorText "📋 Başlat menüsü kısayolu siliniyor..." "Gray"
            Remove-Item $StartMenuShortcut -Force
        }
        
        # Remove from registry
        $RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$AppName"
        if (Test-Path $RegPath) {
            Write-ColorText "📝 Kayıt defterinden kaldırılıyor..." "Gray"
            Remove-Item $RegPath -Force
        }
        
        Write-ColorText ""
        Write-ColorText "✅ KALDIRMA İŞLEMİ BAŞARIYLA TAMAMLANDI!" "Green"
        Write-ColorText ""
        Write-ColorText "$AppName sisteminizden tamamen kaldırıldı." "Cyan"
        
    } catch {
        Write-ColorText "❌ KALDIRMA HATASI: $($_.Exception.Message)" "Red"
    }
}

# Main execution
if ($Uninstall) {
    if (Test-Installation) {
        $confirmation = Read-Host "$AppName kaldırılsın mı? (Y/N)"
        if ($confirmation -eq 'Y' -or $confirmation -eq 'y') {
            Uninstall-Application
        } else {
            Write-ColorText "Kaldırma işlemi iptal edildi." "Yellow"
        }
    } else {
        Write-ColorText "$AppName yüklü görünmüyor." "Yellow"
    }
} else {
    if (Test-Installation) {
        Write-ColorText "⚠️ $AppName zaten yüklü görünüyor." "Yellow"
        $confirmation = Read-Host "Yeniden yüklemek istiyor musunuz? (Y/N)"
        if ($confirmation -eq 'Y' -or $confirmation -eq 'y') {
            Install-Application
        } else {
            Write-ColorText "Kurulum iptal edildi." "Yellow"
        }
    } else {
        $success = Install-Application
        if ($success) {
            $launch = Read-Host "Uygulamayı şimdi başlatmak ister misiniz? (Y/N)"
            if ($launch -eq 'Y' -or $launch -eq 'y') {
                Start-Process "$InstallPath\$ExecutableName" -Verb RunAs
            }
        }
    }
}

Write-ColorText ""
Write-Host "Devam etmek için herhangi bir tuşa basın..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")